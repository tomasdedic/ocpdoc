---
title: "Alumin"
date: 
author: Tomas Dedic
description: "Desc"
lead: "working"
categories:
  - "Azure"
tags:
  - "ACR"
resources:
- name: header
  src: images/sunset.jpg
  type: image
---
# AHOJ alumine
