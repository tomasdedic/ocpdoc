---
title: "Single more to come"
date: 2020-05-27 
author: Tomas Dedic
description: "Desc"
categories:
  - "Single"
tags:
  - "Single"
resources:
- name: header
  src: images/sunset.jpg
  type: image
sidebar: true
menu: side
---
Tady se resi picoviny
